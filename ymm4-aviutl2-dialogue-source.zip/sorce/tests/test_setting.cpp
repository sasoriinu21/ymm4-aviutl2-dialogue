#include "setting.hpp"

#include <cassert>
#include <filesystem>
#include <fstream>
#include <stdexcept>

#include <nlohmann/json.hpp>

#include "content_loader.hpp"
#include "style_applier.hpp"

namespace {
template <typename Function>
void MustThrow(Function&& fn) {
    bool did_throw = false;
    try { fn(); } catch (const std::exception&) { did_throw = true; }
    assert(did_throw);
}

void WriteJson(const std::filesystem::path& path, const nlohmann::json& value) {
    std::ofstream out(path, std::ios::binary);
    out << value.dump(2);
}
}

int main() {
    const auto sample_path = std::filesystem::path(DIALOGUE_SAMPLE_PATH);
    const auto setting = ParseSettingFile(sample_path);
    assert(setting.timeline.size() == 3);
    assert(setting.characters.contains("reimu"));

    auto plan = BuildTimeline(setting, 30, 1, 100, 2);
    assert(plan.items.size() == 3);
    assert(plan.items[0].frame == 100 && plan.items[0].duration == 60);
    assert(plan.items[1].frame == 130 && plan.items[1].duration == 45);
    assert(plan.items[2].frame == 185 && plan.items[2].duration == 35);
    assert(plan.items[1].frame < plan.items[0].frame + plan.items[0].duration);
    assert(plan.items[2].frame >= plan.items[1].frame + plan.items[1].duration);
    const auto line = LoadDialogueText(sample_path.parent_path(), 1);
    assert(line && *line == "今日はマインクラフトをやっていきます！");
    plan.items[0].has_text = true;
    plan.items[0].text = *LoadDialogueText(sample_path.parent_path(), 0);
    const auto text_alias = BuildTextAlias(plan.items[0]);
    assert(text_alias.find("テキスト=こんにちは！\r\n") != std::string::npos);
    const auto audio_alias = BuildAudioAlias(plan.items[0]);
    assert(audio_alias.find("effect.name=音声ファイル") != std::string::npos);
    assert(audio_alias.find("ファイル=\r\n") != std::string::npos);
    assert(audio_alias.find("effect.name=音声再生") != std::string::npos);

    std::ifstream input(sample_path, std::ios::binary);
    const auto root = nlohmann::json::parse(input);
    const auto temp = std::filesystem::temp_directory_path() / "dialogue_setting_invalid_test.json";

    auto duplicate = root;
    duplicate["timeline"][1]["index"] = duplicate["timeline"][0]["index"];
    WriteJson(temp, duplicate);
    MustThrow([&] { ParseSettingFile(temp); });

    auto undefined_character = root;
    undefined_character["timeline"][0]["character"] = "missing";
    WriteJson(temp, undefined_character);
    MustThrow([&] { ParseSettingFile(temp); });

    auto bad_duration = root;
    bad_duration["timeline"][0]["duration"] = 0;
    WriteJson(temp, bad_duration);
    MustThrow([&] { ParseSettingFile(temp); });

    std::filesystem::remove(temp);
    return 0;
}
