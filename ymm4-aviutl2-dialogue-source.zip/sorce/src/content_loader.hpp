#pragma once

#include <filesystem>
#include <optional>
#include <string>

std::optional<std::string> LoadDialogueText(const std::filesystem::path& folder,
                                            unsigned int index);
