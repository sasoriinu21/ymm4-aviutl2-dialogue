#include "style_applier.hpp"

#include <sstream>

namespace {
std::string ColorValue(const std::string& color) { return color.substr(1); }
}

std::string BuildTextAlias(const PlannedItem& item) {
    std::ostringstream alias;
    alias << "[Object]\r\n[Object.0]\r\n"
          << "effect.name=テキスト\r\n"
          << "サイズ=" << item.style->font_size << "\r\n"
          << "文字色=" << ColorValue(item.style->color) << "\r\n"
          << "テキスト=";
    if (item.has_text) {
        alias << item.text;
    } else {
        alias << '[';
        alias.width(4);
        alias.fill('0');
        alias << item.item.index << ']';
    }
    alias << "\r\n"
          << "[Object.1]\r\n"
          << "effect.name=標準描画\r\n"
          << "X=" << item.style->x << "\r\n"
          << "Y=" << item.style->y << "\r\n";
    if (item.style->outline_width > 0) {
        alias << "[Object.2]\r\n"
              << "effect.name=縁取り\r\n"
              << "サイズ=" << item.style->outline_width << "\r\n"
              << "縁色=" << ColorValue(item.style->outline_color) << "\r\n";
    }
    return alias.str();
}

std::string BuildAudioAlias(const PlannedItem& item) {
    std::ostringstream alias;
    alias << "[Object]\r\n"
          << "[Object.0]\r\n"
          << "effect.name=音声ファイル\r\n"
          << "再生位置=0.000,0.000,再生範囲,0\r\n"
          << "再生速度=100.00\r\n"
          << "ファイル=\r\n"
          << "トラック=0\r\n"
          << "ループ再生=0\r\n"
          << "[Object.1]\r\n"
          << "effect.name=音声再生\r\n"
          << "音量=" << item.style->volume << ".00\r\n"
          << "左右=0.00\r\n";
    return alias.str();
}
