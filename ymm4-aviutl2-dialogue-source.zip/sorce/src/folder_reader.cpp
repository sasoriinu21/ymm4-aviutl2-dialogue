#include "folder_reader.hpp"

#include <stdexcept>

#include <windows.h>
#include <shlobj.h>

std::filesystem::path SelectDialogueFolder() {
    BROWSEINFOW info{};
    info.lpszTitle = L"dialogue.setting があるフォルダを選択してください";
    info.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE | BIF_EDITBOX;
    PIDLIST_ABSOLUTE pidl = SHBrowseForFolderW(&info);
    if (!pidl) return {};
    wchar_t selected[MAX_PATH]{};
    const bool ok = SHGetPathFromIDListW(pidl, selected) != FALSE;
    CoTaskMemFree(pidl);
    return ok ? std::filesystem::path(selected) : std::filesystem::path{};
}

std::filesystem::path FindDialogueSetting(const std::filesystem::path& folder) {
    const auto setting = folder / L"dialogue.setting";
    if (!std::filesystem::is_regular_file(setting))
        throw std::runtime_error("選択フォルダ直下に dialogue.setting がありません。");
    return setting;
}
