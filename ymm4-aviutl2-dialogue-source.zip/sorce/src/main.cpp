#include <windows.h>

#include <algorithm>
#include <cstdint>
#include <filesystem>
#include <limits>
#include <memory>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#include "aviutl2_sdk/plugin2.h"
#include "content_loader.hpp"
#include "folder_reader.hpp"
#include "object_factory.hpp"
#include "setting.hpp"

namespace {
constexpr wchar_t kMenuName[] = L"Dialogue Timelineから読み込み...";
constexpr int kLayerSearchLimit = 256;
constexpr int kTextLayerOffset = 2;

bool Intersects(int a_start, int a_length, int b_start, int b_end) {
    const auto a_end = static_cast<long long>(a_start) + a_length;
    return a_start <= b_end && b_start < a_end;
}

bool HasHostCollision(EDIT_SECTION* edit, int layer, int frame, int duration) {
    const auto target_end = static_cast<long long>(frame) + duration - 1;
    int search_frame = 0;
    while (search_frame <= target_end) {
        OBJECT_HANDLE object = edit->find_object(layer, search_frame);
        if (!object) return false;
        const auto range = edit->get_object_layer_frame(object);
        if (range.start > target_end) return false;
        if (range.start <= target_end && range.end >= frame) return true;
        if (range.end < search_frame || range.end == std::numeric_limits<int>::max()) return false;
        search_frame = range.end + 1;
    }
    return false;
}

void AssignNonOverlappingLayers(EDIT_SECTION* edit, TimelinePlan& plan) {
    std::vector<size_t> order(plan.items.size());
    for (size_t i = 0; i < order.size(); ++i) order[i] = i;
    std::stable_sort(order.begin(), order.end(), [&](size_t a, size_t b) {
        return plan.items[a].frame < plan.items[b].frame;
    });
    std::vector<size_t> assigned;
    for (size_t index : order) {
        auto& item = plan.items[index];
        bool found = false;
        const int first_layer = plan.insertion_layer + kTextLayerOffset;
        for (int layer = first_layer; layer <= first_layer + kLayerSearchLimit; ++layer) {
            if (HasHostCollision(edit, layer, item.frame, item.duration)) continue;
            bool conflict = false;
            for (size_t prior : assigned) {
                const auto& other = plan.items[prior];
                if (other.layer == layer && Intersects(item.frame, item.duration, other.frame,
                                                        other.frame + other.duration - 1)) {
                    conflict = true;
                    break;
                }
            }
            if (!conflict) {
                item.layer = layer;
                found = true;
                break;
            }
        }
        if (!found) throw std::runtime_error("空いているレイヤーを256段以内で見つけられませんでした。");
        assigned.push_back(index);
    }
}

void AssignAudioLayers(EDIT_SECTION* edit, TimelinePlan& plan) {
    std::vector<size_t> order(plan.items.size());
    for (size_t i = 0; i < order.size(); ++i) order[i] = i;
    std::stable_sort(order.begin(), order.end(), [&](size_t a, size_t b) {
        return plan.items[a].frame < plan.items[b].frame;
    });
    std::vector<size_t> assigned;
    const int first_layer = plan.insertion_layer;
    for (size_t index : order) {
        auto& item = plan.items[index];
        bool found = false;
        for (int layer = first_layer; layer <= first_layer + kLayerSearchLimit; ++layer) {
            if (HasHostCollision(edit, layer, item.frame, item.duration)) continue;
            bool conflict = false;
            for (const auto& text : plan.items) {
                if (text.layer == layer) {
                    conflict = true;
                    break;
                }
            }
            if (conflict) continue;
            for (size_t prior : assigned) {
                const auto& other = plan.items[prior];
                if (other.audio_layer == layer && Intersects(item.frame, item.duration,
                        other.frame, other.frame + other.duration - 1)) {
                    conflict = true;
                    break;
                }
            }
            if (!conflict) {
                item.audio_layer = layer;
                found = true;
                break;
            }
        }
        if (!found) throw std::runtime_error("空いている音声レイヤーが見つかりませんでした。");
        assigned.push_back(index);
    }
}

void ImportDialogue(EDIT_SECTION* edit) {
    const auto folder = SelectDialogueFolder();
    if (folder.empty()) return;

    try {
        const auto setting_path = FindDialogueSetting(folder);
        const DialogueSetting setting = ParseSettingFile(setting_path);
        if (!edit || !edit->info) throw std::runtime_error("AviUtl2の編集情報を取得できません。");

        TimelinePlan plan = BuildTimeline(setting, edit->info->rate, edit->info->scale,
                                          edit->info->frame, edit->info->layer);
        for (auto& item : plan.items) {
            if (item.item.audio_path.empty()) {
                throw std::runtime_error("Timeline entry " + std::to_string(item.item.index) +
                                         " has no 'audio' path in dialogue.setting.");
            }
            const auto text = LoadDialogueText(folder, item.item.index);
            if (text) {
                item.has_text = true;
                item.text = *text;
            }
        }
        AssignNonOverlappingLayers(edit, plan);
        AssignAudioLayers(edit, plan);

        int created = 0;
        for (const auto& item : plan.items) {
            OBJECT_HANDLE object = CreateDialogueText(edit, item);
            if (!object) {
                std::ostringstream message;
                message << "オブジェクトの作成に失敗しました（index=" << item.item.index
                        << "）。" << created << "個は作成済みです。必要なら直前の操作をUndoしてください。";
                throw std::runtime_error(message.str());
            }
            ++created;
        }

        int audio_created = 0;
        for (const auto& item : plan.items) {
            OBJECT_HANDLE object = CreateDialogueAudio(edit, item);
            if (!object) {
                std::ostringstream message;
                message << "空の音声オブジェクトの作成に失敗しました（index=" << item.item.index
                        << "）。テキスト " << created << " 個、音声 " << audio_created
                        << " 個は作成済みです。必要なら直前の操作をUndoしてください。";
                throw std::runtime_error(message.str());
            }
            ++audio_created;
        }

        std::wostringstream summary;
        summary << L"字幕 " << created << L" 個と空の音声オブジェクト "
                << audio_created << L" 個を配置しました。\n"
                << L"開始位置: フレーム " << plan.insertion_frame << L" / レイヤー "
                << (plan.insertion_layer + 1) << L"（UI表示）";
        MessageBoxW(nullptr, summary.str().c_str(), L"Dialogue Timeline", MB_OK | MB_ICONINFORMATION);
    } catch (const std::exception& e) {
        const int chars = MultiByteToWideChar(CP_UTF8, 0, e.what(), -1, nullptr, 0);
        std::wstring message(static_cast<size_t>(std::max(chars, 1)), L'\0');
        MultiByteToWideChar(CP_UTF8, 0, e.what(), -1, message.data(), chars);
        MessageBoxW(nullptr, message.c_str(), L"Dialogue Timeline: 読み込みエラー", MB_OK | MB_ICONERROR);
    }
}
}

EXTERN_C __declspec(dllexport) void RegisterPlugin(HOST_APP_TABLE* host) {
    if (!host) return;
    host->register_import_menu(kMenuName, ImportDialogue);
}
