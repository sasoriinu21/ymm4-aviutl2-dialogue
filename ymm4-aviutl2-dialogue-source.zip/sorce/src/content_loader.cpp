#include "content_loader.hpp"

#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>

std::optional<std::string> LoadDialogueText(const std::filesystem::path& folder,
                                            unsigned int index) {
    std::ostringstream filename;
    filename << std::setw(4) << std::setfill('0') << index << ".txt";
    const auto path = folder / L"text" / filename.str();
    if (!std::filesystem::exists(path)) return std::nullopt;
    if (!std::filesystem::is_regular_file(path))
        throw std::runtime_error("text content path is not a regular file.");
    if (std::filesystem::file_size(path) > 1024 * 1024)
        throw std::runtime_error("A dialogue text file exceeds the 1 MiB safety limit.");

    std::ifstream stream(path, std::ios::binary);
    if (!stream) throw std::runtime_error("Could not open a dialogue text file.");
    std::string text((std::istreambuf_iterator<char>(stream)), std::istreambuf_iterator<char>());
    if (text.size() >= 3 && static_cast<unsigned char>(text[0]) == 0xEF &&
        static_cast<unsigned char>(text[1]) == 0xBB &&
        static_cast<unsigned char>(text[2]) == 0xBF) {
        text.erase(0, 3);
    }
    while (!text.empty() && (text.back() == '\r' || text.back() == '\n')) text.pop_back();
    if (text.find('\r') != std::string::npos || text.find('\n') != std::string::npos)
        throw std::runtime_error("Each text/*.txt file must contain one line in V1.");
    return text;
}
