#pragma once

#include <string>

#include "setting.hpp"

std::string BuildTextAlias(const PlannedItem& item);
std::string BuildAudioAlias(const PlannedItem& item);
