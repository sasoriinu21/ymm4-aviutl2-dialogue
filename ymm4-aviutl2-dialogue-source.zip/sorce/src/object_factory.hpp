#pragma once

#include <cstdint>
#include <windows.h>

#include "aviutl2_sdk/plugin2.h"
#include "setting.hpp"

OBJECT_HANDLE CreateDialogueText(EDIT_SECTION* edit, const PlannedItem& item);
OBJECT_HANDLE CreateDialogueAudio(EDIT_SECTION* edit, const PlannedItem& item);
