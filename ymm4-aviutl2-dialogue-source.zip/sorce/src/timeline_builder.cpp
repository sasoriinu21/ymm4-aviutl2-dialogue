#include "setting.hpp"

#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>

TimelinePlan BuildTimeline(const DialogueSetting& setting, int project_rate,
                           int project_scale, int insertion_frame, int insertion_layer) {
    if (project_rate <= 0 || project_scale <= 0) throw std::runtime_error("Project frame rate is invalid.");
    if (insertion_frame < 0 || insertion_layer < 0) throw std::runtime_error("Insertion position is invalid.");
    const long double project_fps = static_cast<long double>(project_rate) / project_scale;
    const long double ratio = project_fps / setting.fps;

    TimelinePlan plan;
    plan.insertion_frame = insertion_frame;
    plan.insertion_layer = insertion_layer;
    plan.items.reserve(setting.timeline.size());
    for (const auto& item : setting.timeline) {
        const long double frame = insertion_frame + std::round(static_cast<long double>(item.offset) * ratio);
        const long double duration = std::round(static_cast<long double>(item.duration) * ratio);
        if (frame > std::numeric_limits<int>::max() || duration > std::numeric_limits<int>::max())
            throw std::runtime_error("FPS conversion exceeds AviUtl2 frame limits.");
        PlannedItem planned;
        planned.item = item;
        planned.style = &setting.characters.at(item.character);
        planned.frame = static_cast<int>(frame);
        planned.duration = std::max(1, static_cast<int>(duration));
        planned.layer = insertion_layer;
        if (planned.frame > std::numeric_limits<int>::max() - planned.duration)
            throw std::runtime_error("An object would extend beyond AviUtl2 frame limits.");
        plan.items.push_back(std::move(planned));
    }
    return plan;
}
