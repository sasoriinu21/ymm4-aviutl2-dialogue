#pragma once

#include <cstdint>
#include <filesystem>
#include <map>
#include <string>
#include <vector>

struct CharacterStyle {
    std::string id;
    std::string name;
    std::string font;
    int font_size = 48;
    bool bold = false;
    std::string color = "#FFFFFF";
    std::string outline_color = "#000000";
    int outline_width = 0;
    int x = 0;
    int y = 0;
    std::string alignment = "bottom_center";
    int volume = 100;
};

struct DialogueItem {
    std::uint32_t index = 0;
    std::string character;
    std::int64_t offset = 0;
    std::int64_t duration = 0;
    std::filesystem::path audio_path;
};

struct DialogueSetting {
    int version = 0;
    int fps = 0;
    int width = 0;
    int height = 0;
    std::map<std::string, CharacterStyle> characters;
    std::vector<DialogueItem> timeline;
};

struct PlannedItem {
    DialogueItem item;
    const CharacterStyle* style = nullptr;
    int frame = 0;
    int duration = 0;
    int layer = 0;
    int audio_layer = 0;
    bool has_text = false;
    std::string text;
};

struct TimelinePlan {
    std::vector<PlannedItem> items;
    int insertion_frame = 0;
    int insertion_layer = 0;
};

DialogueSetting ParseSettingFile(const std::filesystem::path& file);
TimelinePlan BuildTimeline(const DialogueSetting& setting, int project_rate,
                           int project_scale, int insertion_frame, int insertion_layer);
