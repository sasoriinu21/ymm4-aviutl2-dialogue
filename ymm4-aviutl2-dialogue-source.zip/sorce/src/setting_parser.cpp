#include "setting.hpp"

#include <fstream>
#include <limits>
#include <set>
#include <stdexcept>

#include <nlohmann/json.hpp>

namespace {
using json = nlohmann::json;

int ReadInt(const json& value, const char* key, int min, int max) {
    const auto& v = value.at(key);
    if (!v.is_number_integer()) throw std::runtime_error(std::string("'") + key + "' must be an integer.");
    const auto n = v.get<std::int64_t>();
    if (n < min || n > max) throw std::runtime_error(std::string("'") + key + "' is out of range.");
    return static_cast<int>(n);
}

std::string ReadString(const json& value, const char* key, bool allow_empty = false) {
    const auto& v = value.at(key);
    if (!v.is_string()) throw std::runtime_error(std::string("'") + key + "' must be a string.");
    auto result = v.get<std::string>();
    if (!allow_empty && result.empty()) throw std::runtime_error(std::string("'") + key + "' must not be empty.");
    return result;
}

bool ReadBool(const json& value, const char* key) {
    const auto& v = value.at(key);
    if (!v.is_boolean()) throw std::runtime_error(std::string("'") + key + "' must be a boolean.");
    return v.get<bool>();
}

std::int64_t ReadNonnegativeInt64(const json& value, const char* key, bool allow_zero) {
    const auto& v = value.at(key);
    if (!v.is_number_integer()) throw std::runtime_error(std::string("'") + key + "' must be an integer.");
    const auto n = v.get<std::int64_t>();
    if (n < (allow_zero ? 0 : 1) || n > std::numeric_limits<int>::max())
        throw std::runtime_error(std::string("'") + key + "' is out of range.");
    return n;
}

void ValidateColor(const std::string& color, const char* name) {
    if (color.size() != 7 || color[0] != '#')
        throw std::runtime_error(std::string("'") + name + "' must use #RRGGBB format.");
    for (size_t i = 1; i < color.size(); ++i) {
        const char c = color[i];
        if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')))
            throw std::runtime_error(std::string("'") + name + "' must use #RRGGBB format.");
    }
}
}

DialogueSetting ParseSettingFile(const std::filesystem::path& file) {
    std::ifstream stream(file, std::ios::binary);
    if (!stream) throw std::runtime_error("Could not open dialogue.setting.");
    json root;
    try { stream >> root; }
    catch (const json::exception& e) { throw std::runtime_error(std::string("Invalid JSON: ") + e.what()); }
    if (!root.is_object()) throw std::runtime_error("Root JSON value must be an object.");
    if (ReadString(root, "format") != "dialogue") throw std::runtime_error("format must be 'dialogue'.");

    DialogueSetting result;
    result.version = ReadInt(root, "version", 1, 1);
    result.fps = ReadInt(root, "fps", 1, 1000);
    result.width = ReadInt(root, "width", 1, 32768);
    result.height = ReadInt(root, "height", 1, 32768);

    const auto& chars = root.at("characters");
    if (!chars.is_object() || chars.empty()) throw std::runtime_error("characters must be a non-empty object.");
    for (auto it = chars.begin(); it != chars.end(); ++it) {
        if (!it.value().is_object()) throw std::runtime_error("Each character must be an object.");
        CharacterStyle c;
        c.id = it.key();
        c.name = ReadString(it.value(), "name");
        c.font = ReadString(it.value(), "font");
        c.font_size = ReadInt(it.value(), "font_size", 1, 1000);
        c.bold = ReadBool(it.value(), "bold");
        c.color = ReadString(it.value(), "color"); ValidateColor(c.color, "color");
        c.outline_color = ReadString(it.value(), "outline_color"); ValidateColor(c.outline_color, "outline_color");
        c.outline_width = ReadInt(it.value(), "outline_width", 0, 1000);
        c.x = ReadInt(it.value(), "x", -100000, 100000);
        c.y = ReadInt(it.value(), "y", -100000, 100000);
        c.alignment = ReadString(it.value(), "alignment");
        c.volume = ReadInt(it.value(), "volume", 0, 100);
        result.characters.emplace(c.id, std::move(c));
    }

    const auto& timeline = root.at("timeline");
    if (!timeline.is_array()) throw std::runtime_error("timeline must be an array.");
    if (timeline.size() > 10000) throw std::runtime_error("timeline exceeds the 10000 item safety limit.");
    std::set<std::uint32_t> seen;
    for (const auto& entry : timeline) {
        if (!entry.is_object()) throw std::runtime_error("Each timeline entry must be an object.");
        const auto idx = ReadNonnegativeInt64(entry, "index", true);
        DialogueItem item;
        item.index = static_cast<std::uint32_t>(idx);
        if (!seen.insert(item.index).second) throw std::runtime_error("Duplicate timeline index: " + std::to_string(item.index));
        item.character = ReadString(entry, "character");
        if (!result.characters.contains(item.character))
            throw std::runtime_error("Undefined character: " + item.character);
        item.offset = ReadNonnegativeInt64(entry, "offset", true);
        item.duration = ReadNonnegativeInt64(entry, "duration", false);
        if (entry.contains("audio")) {
            const auto audio_utf8 = ReadString(entry, "audio");
            const auto audio = std::filesystem::path(std::u8string(
                reinterpret_cast<const char8_t*>(audio_utf8.data()), audio_utf8.size()));
            if (audio.is_absolute() || audio.has_root_name() || audio.has_root_directory())
                throw std::runtime_error("'audio' must be a relative path inside the dialogue folder.");
            for (const auto& component : audio) {
                if (component == "..")
                    throw std::runtime_error("'audio' must not escape the dialogue folder.");
            }
            item.audio_path = std::filesystem::absolute(file.parent_path() / audio).lexically_normal();
            if (!std::filesystem::is_regular_file(item.audio_path))
                throw std::runtime_error("Referenced audio file was not found: " + audio_utf8);
        }
        result.timeline.push_back(std::move(item));
    }
    return result;
}
