#pragma once

#include <filesystem>

std::filesystem::path SelectDialogueFolder();
std::filesystem::path FindDialogueSetting(const std::filesystem::path& folder);
