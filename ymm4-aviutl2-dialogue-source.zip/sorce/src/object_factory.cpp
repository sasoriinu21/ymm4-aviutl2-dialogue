#include "object_factory.hpp"

#include <iomanip>
#include <sstream>
#include <string>
#include <vector>

#include <windows.h>

#include "style_applier.hpp"

namespace {
OBJECT_HANDLE CreateNamedAliasObject(EDIT_SECTION* edit, const std::string& alias,
                                     int layer, const PlannedItem& item) {
    OBJECT_HANDLE object = edit->create_object_from_alias(alias.c_str(), layer,
                                                          item.frame, item.duration);
    if (!object) return nullptr;

    std::ostringstream object_name;
    if (item.has_text) object_name << item.text;
    object_name << '[' << std::setw(4) << std::setfill('0') << item.item.index << ']';
    const std::string utf8_name = object_name.str();
    const int wide_length = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS,
                                                utf8_name.c_str(), -1, nullptr, 0);
    if (wide_length > 0) {
        std::vector<wchar_t> wide_name(static_cast<size_t>(wide_length));
        if (MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, utf8_name.c_str(), -1,
                                wide_name.data(), wide_length) > 0) {
            edit->set_object_name(object, wide_name.data());
        }
    }
    return object;
}
}

OBJECT_HANDLE CreateDialogueText(EDIT_SECTION* edit, const PlannedItem& item) {
    return CreateNamedAliasObject(edit, BuildTextAlias(item), item.layer, item);
}

OBJECT_HANDLE CreateDialogueAudio(EDIT_SECTION* edit, const PlannedItem& item) {
    OBJECT_HANDLE object = CreateNamedAliasObject(edit, BuildAudioAlias(item), item.audio_layer, item);
    if (!object) return nullptr;

    const auto path_utf8 = item.item.audio_path.u8string();
    const std::string path(reinterpret_cast<const char*>(path_utf8.data()), path_utf8.size());
    if (!edit->set_object_item_value(object, L"音声ファイル", L"ファイル", path.c_str()))
        return nullptr;
    return object;
}
