$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$sdk = Join-Path $root 'sdk\aviutl2_sdk_mirror'

if (Test-Path (Join-Path $sdk '.git')) {
    git -C $sdk pull --ff-only
} else {
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $sdk) | Out-Null
    git clone --depth 1 https://github.com/aviutl2/aviutl2_sdk_mirror.git $sdk
}
if ($LASTEXITCODE -ne 0) { throw 'SDK download failed.' }
