# Dialogue Timeline for AviUtl2

`dialogue.setting` と同じフォルダにある字幕・音声素材を読み込み、AviUtl2のタイムラインに配置するインポートプラグインです。YMM4 Dialogue Exportの出力形式に対応しています。

## 使い方

1. 「ファイル > インポート > Dialogue Timeline読み込み...」を選択します。
2. `dialogue.setting`、`text/`、`audio/` を含むフォルダを選択します。
3. 再生ヘッド位置と選択レイヤーを基準に、字幕と音声オブジェクトを配置します。

音声パスは `dialogue.setting` 内の相対パスから解決し、AviUtl2の音声ファイル項目へ絶対パスとして設定します。参照先ファイルが見つからない場合は、読み込み前にエラーになります。

## 対応データ

- `timeline[].index`, `character`, `offset`, `duration`, `audio`
- `audio` は会話フォルダ内の相対パスです。フォルダ外を参照するパスは受け付けません。
- `text/0000.txt` のようにインデックスに対応するUTF-8テキストを読み込みます。ファイルがない場合、字幕にはインデックスを表示します。
- FPSに基づいてオフセットと長さをプロジェクトのフレームへ変換します。
- 字幕の文字サイズ、文字色、縁取り、座標、およびキャラクター音量を反映します。

## ビルド

Windows x64、Visual Studio C++ Build Tools、Windows SDK、CMake 3.24以降が必要です。

```powershell
.\scripts\setup-sdk.ps1
cmake -S . -B build -A x64
cmake --build build --config Release
```

出力は `build/Release/DialogueTimeline.aux2` です。SDKとnlohmann/jsonの取得時にネットワーク接続が必要です。

## 開発状況

開発中の初期版です。ビルドは確認済みです。音声参照の最新修正はAviUtl2上での再生確認が必要です。YMM4の設定を全て再現するものではありません。
