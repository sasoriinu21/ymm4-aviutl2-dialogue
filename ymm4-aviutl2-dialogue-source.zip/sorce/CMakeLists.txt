cmake_minimum_required(VERSION 3.24)
project(DialogueTimeline LANGUAGES CXX)

if(NOT WIN32)
    message(FATAL_ERROR "DialogueTimeline is an AviUtl2 Windows plugin.")
endif()

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

set(AVIUTL2_SDK_DIR "${CMAKE_CURRENT_SOURCE_DIR}/sdk/aviutl2_sdk_mirror" CACHE PATH
    "Path to aviutl2_sdk_mirror")
if(NOT EXISTS "${AVIUTL2_SDK_DIR}/include/aviutl2_sdk/plugin2.h")
    message(FATAL_ERROR "AviUtl2 SDK missing. Run scripts/setup-sdk.ps1 or set AVIUTL2_SDK_DIR.")
endif()

include(FetchContent)
FetchContent_Declare(nlohmann_json
    GIT_REPOSITORY https://github.com/nlohmann/json.git
    GIT_TAG v3.12.0
    GIT_SHALLOW TRUE)
FetchContent_MakeAvailable(nlohmann_json)

add_library(DialogueTimeline SHARED
    src/content_loader.cpp
    src/folder_reader.cpp
    src/main.cpp
    src/object_factory.cpp
    src/setting_parser.cpp
    src/style_applier.cpp
    src/timeline_builder.cpp)
target_include_directories(DialogueTimeline PRIVATE
    "${AVIUTL2_SDK_DIR}/include"
    "${CMAKE_CURRENT_SOURCE_DIR}/src")
target_link_libraries(DialogueTimeline PRIVATE nlohmann_json::nlohmann_json Shell32 Ole32)
target_compile_definitions(DialogueTimeline PRIVATE UNICODE _UNICODE NOMINMAX WIN32_LEAN_AND_MEAN)
set_target_properties(DialogueTimeline PROPERTIES PREFIX "" SUFFIX ".aux2")

include(CTest)
if(BUILD_TESTING)
    add_executable(dialogue_setting_tests
        tests/test_setting.cpp
        src/content_loader.cpp
        src/setting_parser.cpp
        src/style_applier.cpp
        src/timeline_builder.cpp)
    target_include_directories(dialogue_setting_tests PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}/src")
    target_link_libraries(dialogue_setting_tests PRIVATE nlohmann_json::nlohmann_json)
    target_compile_definitions(dialogue_setting_tests PRIVATE
        DIALOGUE_SAMPLE_PATH="${CMAKE_CURRENT_SOURCE_DIR}/tests/dialogue.setting")
    if(MSVC)
        target_compile_options(dialogue_setting_tests PRIVATE /W4 /permissive- /utf-8)
    endif()
    add_test(NAME dialogue_setting_tests COMMAND dialogue_setting_tests)
endif()

if(MSVC)
    target_compile_options(DialogueTimeline PRIVATE /W4 /permissive- /utf-8)
endif()
