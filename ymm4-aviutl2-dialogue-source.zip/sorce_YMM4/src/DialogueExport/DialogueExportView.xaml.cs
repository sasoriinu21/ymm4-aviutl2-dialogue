using System.Windows.Controls;

namespace DialogueExport;

public partial class DialogueExportView : UserControl
{
    public DialogueExportView()
    {
        InitializeComponent();
    }
}
