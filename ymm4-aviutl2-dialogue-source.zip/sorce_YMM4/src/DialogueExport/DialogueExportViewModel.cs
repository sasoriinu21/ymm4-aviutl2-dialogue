using System.IO;
using System.Windows.Input;
using Microsoft.Win32;
using YukkuriMovieMaker.Commons;
using YukkuriMovieMaker.Plugin;
using YukkuriMovieMaker.Project;
using YukkuriMovieMaker.Project.Items;

namespace DialogueExport;

public sealed class DialogueExportViewModel : Bindable, IToolViewModel, ITimelineToolViewModel
{
    private Timeline? _timeline;
    private VideoInfo? _videoInfo;
    private string _saveName = "export";
    private string _destinationParent = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
    private string _status = "YMM4のタイムライン情報を待っています。";

    public string Title => "Dialogue出力";
    public bool CanSuspend => false;
    public string SaveName { get => _saveName; set => Set(ref _saveName, value); }
    public string DestinationParent { get => _destinationParent; set => Set(ref _destinationParent, value); }
    public string Status { get => _status; private set => Set(ref _status, value); }

    public ICommand BrowseCommand { get; }
    public ICommand ExportCommand { get; }

    event EventHandler<CreateNewToolViewRequestedEventArgs>? IToolViewModel.CreateNewToolViewRequested
    {
        add { }
        remove { }
    }

    public DialogueExportViewModel()
    {
        BrowseCommand = new ActionCommand(_ => true, _ => BrowseDestination());
        ExportCommand = new ActionCommand(_ => _timeline is not null, _ => _ = ExportAsync());
    }

    public void SetTimelineToolInfo(TimelineToolInfo info)
    {
        _timeline = info?.Timeline;
        _videoInfo = _timeline?.VideoInfo;
        Status = _timeline is null
            ? "現在のタイムラインを取得できません。"
            : $"タイムラインを取得しました（{_videoInfo?.FPS ?? 0} fps）。";
    }

    public void LoadState(ToolState stateData) { }

    public ToolState SaveState() => new() { Title = Title };

    private void BrowseDestination()
    {
        var dialog = new OpenFolderDialog
        {
            Title = "Dialogueフォルダの出力先を選択",
            InitialDirectory = Directory.Exists(DestinationParent)
                ? DestinationParent
                : Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
        };
        if (dialog.ShowDialog() == true) DestinationParent = dialog.FolderName;
    }

    private async Task ExportAsync()
    {
        if (_timeline is null || _videoInfo is null)
        {
            Status = "YMM4のタイムライン情報を取得できません。";
            return;
        }

        var tempDirectory = Path.Combine(Path.GetTempPath(), $"dialogue-audio-{Guid.NewGuid():N}");
        Directory.CreateDirectory(tempDirectory);
        try
        {
            var items = _timeline.Items
                .OfType<VoiceItem>()
                .OrderBy(item => item.Frame)
                .ThenBy(item => item.Layer)
                .ToArray();
            if (items.Length == 0)
            {
                Status = "現在のシーンにボイスアイテムがありません。";
                return;
            }

            var origin = items.Min(item => item.Frame);
            var entries = new List<DialogueEntry>(items.Length);
            var characters = new Dictionary<string, DialogueCharacter>(StringComparer.Ordinal);
            for (var i = 0; i < items.Length; i++)
            {
                var item = items[i];
                var characterName = string.IsNullOrWhiteSpace(item.CharacterName)
                    ? "default"
                    : item.CharacterName;
                var text = item.Serif ?? string.Empty;
                if (string.IsNullOrWhiteSpace(text)) continue;
                var index = (uint)entries.Count;

                if (!characters.ContainsKey(characterName))
                    characters.Add(characterName, CreateCharacterStyle(item, characterName));

                var audioPath = Path.Combine(tempDirectory, index.ToString("D4") + ".wav");
                await item.CreateAudioFileAsync(audioPath, _videoInfo);
                if (!File.Exists(audioPath) || new FileInfo(audioPath).Length == 0)
                    throw new IOException($"音声を書き出せませんでした（index={index}）。");

                entries.Add(new DialogueEntry(
                    index,
                    characterName,
                    item.Frame - origin,
                    Math.Max(1, item.Length),
                    text,
                    audioPath));

                Status = $"音声を書き出しています: {entries.Count}/{items.Length}";
            }

            if (entries.Count == 0)
            {
                Status = "本文のあるボイスアイテムがありません。";
                return;
            }

            var package = new DialoguePackage(
                _videoInfo.FPS,
                _videoInfo.Width,
                _videoInfo.Height,
                characters,
                entries);
            var output = DialoguePackageWriter.Write(DestinationParent, SaveName, package);
            Status = $"{entries.Count}件を書き出しました: {output}";
        }
        catch (Exception ex)
        {
            Status = $"出力に失敗しました: {ex.Message}";
        }
        finally
        {
            try { Directory.Delete(tempDirectory, recursive: true); }
            catch { }
        }
    }

    private static DialogueCharacter CreateCharacterStyle(VoiceItem item, string name)
    {
        return new DialogueCharacter(
            name,
            string.IsNullOrWhiteSpace(item.Font) ? "Yu Gothic UI" : item.Font,
            Color: ToRgb(item.FontColor),
            OutlineColor: ToRgb(item.StyleColor),
            OutlineWidth: 3,
            Bold: item.Bold);
    }

    private static string ToRgb(System.Windows.Media.Color color) =>
        $"#{color.R:X2}{color.G:X2}{color.B:X2}";
}
