using YukkuriMovieMaker.Plugin;

namespace DialogueExport;

public sealed class DialogueExportPlugin : IToolPlugin
{
    public string Name => "Dialogue出力";
    public Type ViewModelType => typeof(DialogueExportViewModel);
    public Type ViewType => typeof(DialogueExportView);
    public bool AllowMultipleInstances => false;
}
