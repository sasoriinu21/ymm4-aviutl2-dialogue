using System.IO;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace DialogueExport;

public sealed record DialogueCharacter(
    string Name,
    string Font,
    int FontSize = 48,
    bool Bold = false,
    string Color = "#FFFFFF",
    string OutlineColor = "#000000",
    int OutlineWidth = 0,
    int X = 0,
    int Y = 0,
    string Alignment = "bottom_center",
    int Volume = 100);

public sealed record DialogueEntry(
    uint Index,
    string Character,
    long Offset,
    long Duration,
    string Text,
    string? AudioPath = null);

public sealed record DialoguePackage(
    int Fps,
    int Width,
    int Height,
    IReadOnlyDictionary<string, DialogueCharacter> Characters,
    IReadOnlyList<DialogueEntry> Timeline);

/// <summary>Writes a self-contained dialogue[saveName] folder.</summary>
public static class DialoguePackageWriter
{
    private static readonly UTF8Encoding Utf8NoBom = new(encoderShouldEmitUTF8Identifier: false);
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower
    };

    public static string Write(string destinationParent, string saveName, DialoguePackage package)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(destinationParent);
        ArgumentException.ThrowIfNullOrWhiteSpace(saveName);
        ArgumentNullException.ThrowIfNull(package);
        Validate(package);

        var safeName = SanitizeName(saveName);
        var parent = Path.GetFullPath(destinationParent);
        Directory.CreateDirectory(parent);
        var destination = Path.Combine(parent, $"dialogue[{safeName}]");
        if (Directory.Exists(destination) || File.Exists(destination))
            throw new IOException($"出力先はすでに存在します: {destination}");

        var staging = Path.Combine(parent, $".dialogue-export-{Guid.NewGuid():N}");
        try
        {
            var textDirectory = Directory.CreateDirectory(Path.Combine(staging, "text")).FullName;
            var audioDirectory = Directory.CreateDirectory(Path.Combine(staging, "audio")).FullName;
            var audioByIndex = new Dictionary<uint, string>();

            foreach (var item in package.Timeline)
            {
                var fileStem = item.Index.ToString("D4", System.Globalization.CultureInfo.InvariantCulture);
                File.WriteAllText(Path.Combine(textDirectory, $"{fileStem}.txt"), item.Text, Utf8NoBom);

                if (string.IsNullOrWhiteSpace(item.AudioPath)) continue;
                var source = Path.GetFullPath(item.AudioPath);
                if (!File.Exists(source))
                    throw new FileNotFoundException($"音声ファイルが見つかりません: {source}", source);

                var extension = Path.GetExtension(source);
                if (string.IsNullOrWhiteSpace(extension)) extension = ".bin";
                var relativeAudioPath = $"audio/{fileStem}{extension.ToLowerInvariant()}";
                File.Copy(source, Path.Combine(audioDirectory, $"{fileStem}{extension.ToLowerInvariant()}"));
                audioByIndex.Add(item.Index, relativeAudioPath);
            }

            var manifest = new DialogueManifest
            {
                Fps = package.Fps,
                Width = package.Width,
                Height = package.Height,
                Characters = package.Characters.ToDictionary(
                    pair => pair.Key,
                    pair => new CharacterManifest(pair.Value),
                    StringComparer.Ordinal),
                Timeline = package.Timeline.Select(item => new TimelineManifest
                {
                    Index = item.Index,
                    Character = item.Character,
                    Offset = item.Offset,
                    Duration = item.Duration,
                    Audio = audioByIndex.GetValueOrDefault(item.Index)
                }).ToList()
            };

            var json = JsonSerializer.Serialize(manifest, JsonOptions);
            File.WriteAllText(Path.Combine(staging, "dialogue.setting"), json, Utf8NoBom);
            Directory.Move(staging, destination);
            return destination;
        }
        finally
        {
            if (Directory.Exists(staging)) Directory.Delete(staging, recursive: true);
        }
    }

    private static void Validate(DialoguePackage package)
    {
        if (package.Fps <= 0 || package.Width <= 0 || package.Height <= 0)
            throw new ArgumentException("FPSと解像度は正の値にしてください。");
        if (package.Characters.Count == 0)
            throw new ArgumentException("キャラクターがありません。");

        var indices = new HashSet<uint>();
        foreach (var item in package.Timeline)
        {
            if (!indices.Add(item.Index))
                throw new ArgumentException($"indexが重複しています: {item.Index}");
            if (!package.Characters.ContainsKey(item.Character))
                throw new ArgumentException($"未定義のキャラクターです: {item.Character}");
            if (item.Offset < 0 || item.Duration <= 0)
                throw new ArgumentException($"セリフ {item.Index} の時刻または長さが不正です。");
            if (item.Text.Contains('\r') || item.Text.Contains('\n'))
                throw new ArgumentException($"セリフ {item.Index} に改行があります。V1では1行の本文にしてください。");
        }
    }

    private static string SanitizeName(string value)
    {
        var invalid = Path.GetInvalidFileNameChars().ToHashSet();
        var result = new string(value.Trim().Select(ch => invalid.Contains(ch) ? '_' : ch).ToArray());
        if (string.IsNullOrWhiteSpace(result) || result is "." or "..")
            throw new ArgumentException("保存名が空か、フォルダ名として使えません。", nameof(value));
        return result;
    }

    private sealed class DialogueManifest
    {
        public string Format { get; init; } = "dialogue";
        public int Version { get; init; } = 1;
        public int Fps { get; init; }
        public int Width { get; init; }
        public int Height { get; init; }
        public required Dictionary<string, CharacterManifest> Characters { get; init; }
        public required List<TimelineManifest> Timeline { get; init; }
    }

    private sealed class CharacterManifest(DialogueCharacter source)
    {
        public string Name { get; } = source.Name;
        public string Font { get; } = source.Font;
        public int FontSize { get; } = source.FontSize;
        public bool Bold { get; } = source.Bold;
        public string Color { get; } = source.Color;
        public string OutlineColor { get; } = source.OutlineColor;
        public int OutlineWidth { get; } = source.OutlineWidth;
        public int X { get; } = source.X;
        public int Y { get; } = source.Y;
        public string Alignment { get; } = source.Alignment;
        public int Volume { get; } = source.Volume;
    }

    private sealed class TimelineManifest
    {
        public uint Index { get; init; }
        public string Character { get; init; } = string.Empty;
        public long Offset { get; init; }
        public long Duration { get; init; }
        [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
        public string? Audio { get; init; }
    }
}
