# YMM4 Dialogue Export

YMM4の現在のシーンから、AviUtl2 Dialogue Timeline用のフォルダを書き出すプラグインです。

## 出力形式

```text
dialogue[保存名]/
├─ dialogue.setting
├─ text/0000.txt
└─ audio/0000.wav
```

音声はWAV形式で保存します。`dialogue.setting` の `timeline` 各項目に、同じインデックスの音声ファイルへの相対パスを記録します。テキストと音声はインデックスで対応します。オフセットと長さは設定FPS基準のフレーム数です。

## 現在の機能

- YMM4のツールプラグインとして「Dialogue出力」画面を追加します。
- 現在のシーンのボイスアイテムを取得し、開始位置を0にそろえて出力します。
- ボイスごとの音声をWAVとして書き出し、字幕本文をUTF-8テキストで保存します。
- キャラクター名、フォント、色、音量、FPS、解像度を記録します。

YMM4 4.57.0.1の参照DLLを用いてビルド確認済みです。

## ビルド

.NET 10 SDKとYMM4本体が必要です。既定ではYMM4を `C:\Program Files\YukkuriMovieMaker_v4\` から参照します。

```powershell
dotnet build .\src\DialogueExport\DialogueExport.csproj -c Release
```

別の場所にYMM4をインストールしている場合:

```powershell
dotnet build .\src\DialogueExport\DialogueExport.csproj -c Release -p:YMM4DirPath="D:\Apps\YMM4\"
```

## 開発状況

開発中の初期版です。YMM4側の画面やインストール手順、対応バージョンの説明は今後整備します。
